package com.acheng.achengutils.mvp.model;

/**
 * Created by acheng on 2016/7/14.
 */
public interface BaseViewController {

}
