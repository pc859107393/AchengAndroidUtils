package com.acheng.achengutils.widgets;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.widget.DatePicker;
import android.widget.TimePicker;


import java.util.Calendar;

/**
 * Created by acheng on 2016/5/7 0007.
 */
public class CreatDateOrTimePicker {

    private static final int DATE_DIALOG = 0;
    private static final int TIME_DIALOG = 1;
    private NeedDoThing needDoThing;
    private Context context;
    private Calendar c = Calendar.getInstance();
    private Dialog dialog;


    public static abstract class NeedDoThing {  //内部类在使用的时候才会被初始化
        public void doThing(int year, int month, int dayOfMonth) {
            if (0 == year || month + 1 == 0 || dayOfMonth == 0) {
                throw new IllegalArgumentException("Using the method of abnormal, please check your reference method!");
            }
        }

        public void doThing(int hourOfDay, int minute) {
//            if (0 == hourOfDay || minute == 0) {
//                throw new IllegalArgumentException("Using the method of abnormal, please check your reference method!");
//            }
        }
    }

    /**
     * 创建一键选择日期时间对话框
     *
     * @param creatID     0创建日期 1时间
     * @param context     上下文
     * @param needDoThing 需要做的事情回调
     */
    public void CreatDateOrTimePicker(int creatID, Context context, NeedDoThing needDoThing) {
        this.needDoThing = needDoThing;
        this.context = context;
        switch (creatID) {
            case DATE_DIALOG:
                dayDialog();
                break;
            case TIME_DIALOG:
                timeDialog();
                break;
        }
    }

    /**
     * 创建日期及时间选择对话框
     */
    private void dayDialog() {
        if (null != dialog && dialog.isShowing()) {
            dialog.dismiss();
        }
        dialog = new DatePickerDialog(
                context,
                new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker dp, int year, int month, int dayOfMonth) {
                        needDoThing.doThing(year, month, dayOfMonth);
                    }
                },
                c.get(Calendar.YEAR), // 传入年份
                c.get(Calendar.MONTH), // 传入月份
                c.get(Calendar.DAY_OF_MONTH) // 传入天数
        );
        if (!dialog.isShowing()) {
            dialog.show();
        }
    }

    /**
     * 创建日期及时间选择对话框
     */
    private void timeDialog() {
        if (null != dialog && dialog.isShowing()) {
            dialog.dismiss();
        }
        dialog = new TimePickerDialog(
                context,
                new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        needDoThing.doThing(hourOfDay, minute);
                    }
                },
                c.get(Calendar.HOUR_OF_DAY),
                c.get(Calendar.MINUTE),
                true
        );
        if (!dialog.isShowing()) {
            dialog.show();
        }
    }
}

