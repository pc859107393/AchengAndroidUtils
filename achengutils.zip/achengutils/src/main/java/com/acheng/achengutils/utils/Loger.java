/*
 * Copyright (c) 2014,KJFrameForAndroid Open Source Project,张涛.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.acheng.achengutils.utils;

import android.util.Log;

public final class Loger {
    private static boolean CAN_LOG_I = true;
    private static boolean DEBUG_LOG = true;
    private static boolean SHOW_ACTIVITY_STATE = true;
    private static String TAG = "aChengUtils";

    public static void closeLog() {
        CAN_LOG_I = false;
        DEBUG_LOG = false;
    }

    public static void setLogTag(String TAG) {
        Loger.TAG = TAG;
    }

    public static void showActivityState(boolean enable) {
        SHOW_ACTIVITY_STATE = enable;
    }

    public static void debug(String msg) {
        if (CAN_LOG_I) {
            Log.i(TAG, msg);
        }
    }


    public static void log(String packName, String state) {
        debugLog(packName, state);
    }

    public static void debug(String msg, Throwable tr) {
        if (CAN_LOG_I) {
            Log.i(TAG, msg, tr);
        }
    }

    public static void activityState(String packName, String state) {
        if (SHOW_ACTIVITY_STATE) {
            Log.d("activity_state", packName + state);
        }
    }

    public static void debugLog(String packName, String state) {
        if (DEBUG_LOG) {
            Log.d(TAG, packName + state);
        }
    }

    public static void exception(Exception e) {
        if (DEBUG_LOG) {
            e.printStackTrace();
        }
    }

    public static void debug(String msg, Object... format) {
        debug(String.format(msg, format));
    }
}
