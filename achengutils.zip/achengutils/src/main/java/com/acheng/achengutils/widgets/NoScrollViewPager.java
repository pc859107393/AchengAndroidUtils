package com.acheng.achengutils.widgets;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;
import android.view.MotionEvent;

/**
 * 重写ViewPager的触摸事件，让ViewPager不能左右滑动
 *
 * @author acheng
 */
public class NoScrollViewPager extends ViewPager {

    public NoScrollViewPager(Context context) {
        super(context);
    }

    public NoScrollViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    @Override
    public boolean onTouchEvent(MotionEvent motionEvent) {
        return false;   //返回false，关闭滑动事件
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        return false;   //强制返回false表示不拦截滑动事件
    }

}
