package com.acheng.achengutils.utils;

import java.math.BigDecimal;
import java.text.DecimalFormat;

public class MathHelper {
    private static final int DEF_DIV_SCALE = 10;

    private MathHelper() {

    }

    /**
     * 提供精确的加法运算。
     *
     * @param v1 被加数
     * @param v2 加数
     * @return 两个参数的和
     */
    public static double add(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.add(b2).doubleValue();
    }

    /**
     * 提供精确的减法运算。
     *
     * @param v1 被减数
     * @param v2 减数
     * @return 两个参数的差
     */
    public static double sub(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.subtract(b2).doubleValue();
    }

    /**
     * 提供精确的乘法运算。
     *
     * @param v1 被乘数
     * @param v2 乘数
     * @return 两个参数的积
     */
    public static double mul(double v1, double v2) {
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.multiply(b2).doubleValue();
    }

    /**
     * 提供（相对）精确的除法运算，当发生除不尽的情况时，精确到 小数点以后10位，以后的数字四舍五入。
     *
     * @param v1 被除数
     * @param v2 除数
     * @return 两个参数的商
     */
    public static double div(double v1, double v2) {
        return div(v1, v2, DEF_DIV_SCALE);
    }

    /**
     * 提供（相对）精确的除法运算。当发生除不尽的情况时，由scale参数指 定精度，以后的数字四舍五入。
     *
     * @param v1    被除数
     * @param v2    除数
     * @param scale 表示表示需要精确到小数点以后几位。
     * @return 两个参数的商
     */

    public static double div(double v1, double v2, int scale) {
        if (scale < 0) {
            throw new IllegalArgumentException(
                    "The scale must be a positive integer or zero");
        }
        BigDecimal b1 = new BigDecimal(Double.toString(v1));
        BigDecimal b2 = new BigDecimal(Double.toString(v2));
        return b1.divide(b2, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    /**
     * 提供精确的小数位四舍五入处理。
     *
     * @param v     需要四舍五入的数字
     * @param scale 小数点后保留几位
     * @return 四舍五入后的结果
     */
    public static double round(double v, int scale) {
        if (scale < 0) {
            throw new IllegalArgumentException(
                    "The scale must be a positive integer or zero");
        }
        BigDecimal b = new BigDecimal(Double.toString(v));
        BigDecimal one = new BigDecimal("1");
        return b.divide(one, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
    }

    /**
     * 字符串乘法
     *
     * @param str1
     * @param str2
     * @return
     */
    public static String strMul(String str1, String str2) {
        if (str1.isEmpty() || str2.isEmpty()) {
            throw new IllegalArgumentException(
                    "乘数不能为空");
        }
        BigDecimal b1 = new BigDecimal(str1);
        BigDecimal b2 = new BigDecimal(str2);
        return b1.multiply(b2).toString();
    }

    public static String add(String str1, String str2, String str3, String str4, String str5) {
        BigDecimal b1 = new BigDecimal(str1);
        BigDecimal b2 = new BigDecimal(str2);
        BigDecimal b3 = new BigDecimal(str3);
        BigDecimal b4 = new BigDecimal(str4);
        BigDecimal b5 = new BigDecimal(str5);

        return b1.add(b2.add(b3.add(b4.add(b5)))).toString();
    }

    /**
     * 字符串乘法
     *
     * @param str1
     * @param str2
     * @return
     */
    public static String strMul(String str1, String str2, String str3) {
        if (str1.isEmpty() || str2.isEmpty()) {
            throw new IllegalArgumentException(
                    "乘数不能为空");
        }
        BigDecimal b1 = new BigDecimal(str1);
        BigDecimal b2 = new BigDecimal(str2);
        BigDecimal b3 = new BigDecimal(str3);
        return (b1.multiply(b2.multiply(b3))).toString();
    }


    /**
     * 字符串乘法
     *
     * @param str1
     * @param str2
     * @return
     */
    public static String nul(String str1, String str2) {
        if (str1.isEmpty() || str2.isEmpty()) {
            throw new IllegalArgumentException(
                    "乘数不能为空");
        }
        BigDecimal b1 = new BigDecimal(str1);
        BigDecimal b2 = new BigDecimal(str2);
        return b1.multiply(b2).toString();
    }


    /**
     * 使用java正则表达式去掉多余的.与0
     *
     * @param s
     * @return
     */
    public static String subZeroAndDot(String s) {
        if (s.indexOf(".") > 0) {
            s = s.replaceAll("0+?$", "");//去掉多余的0
            s = s.replaceAll("[.]$", "");//如最后一位是.则去掉
        }
        return s;
    }

    /**
     * 四舍五入  保留两位小数
     *
     * @param abc
     * @return
     */
    public static String retain2(String abc) {
        DecimalFormat format = new DecimalFormat("0.00");

        String a = format.format(new BigDecimal(abc));


        return a;
    }
}