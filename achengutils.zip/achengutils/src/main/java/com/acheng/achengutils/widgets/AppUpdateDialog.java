package com.acheng.achengutils.widgets;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;


/** app升级提示对话框，使用示例：
 *
 * Created by acheng on 2016/5/31.
 */
public class AppUpdateDialog {
    public final static int IMPORTANT = 1;  //重要更新
    public final static int SIMPLE = 0; //简单更新

    public AppUpdateDialog(int showtype, String message, Context context, final NeedDoThing needDoThing) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);

        if (showtype == IMPORTANT) {
            //重要更新
            builder.setTitle("发现重要更新");
            builder.setMessage(message);
            builder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    needDoThing.mustDoThing();
                }
            });
        } else if (showtype == SIMPLE) {
            //简单更新
            builder.setTitle("发现普通更新");
            builder.setMessage(message);
            builder.setNegativeButton("确定", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    needDoThing.mustDoThing();
                }
            });

            builder.setPositiveButton("忽略", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                    needDoThing.canDoThing();
                }
            });

        } else {
            throw new IllegalArgumentException("erro Argument! Please check your Argument.");
        }

        builder.setCancelable(false);

        builder.show();

    }

    public static abstract class NeedDoThing {
        public abstract void mustDoThing();

        public void canDoThing() {

        }
    }
}
