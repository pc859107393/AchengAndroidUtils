package com.acheng.achengutils.widgets.swiperefreshlayout;

import android.os.Handler;
import android.view.View;


/** 封装上下拉控件
 * Created by 85910 on 2015/10/13 0013.
 */
public class InsertSwipeLayout {
    private View mRootView;
    private SwipyRefreshLayout mSwipeLayout;
    private SwipeLayoutRefreshListener mSwipeLayoutRefreshListener;
    private int mSwipyRefreshViewId;

    public InsertSwipeLayout(View rootView, int swipyRefreshViewId) {
        this.mRootView = rootView;
        this.mSwipyRefreshViewId = swipyRefreshViewId;
        initView();
    }

    private void initView() {
        mSwipeLayout = (SwipyRefreshLayout) mRootView.findViewById(mSwipyRefreshViewId);   //找到下拉刷新控件
        initData();
    }

    private void initData() {
        //实例化下拉刷新监听器
        mSwipeLayoutRefreshListener = new SwipeLayoutRefreshListener();
        //设定下拉刷新监听器
        mSwipeLayout.setOnRefreshListener(mSwipeLayoutRefreshListener);
        // 设置下拉圆圈上的颜色，蓝色、绿色、橙色、红色
        mSwipeLayout.setColorSchemeResources(android.R.color.holo_blue_bright, android.R.color.holo_green_light,
                android.R.color.holo_orange_light, android.R.color.holo_red_light);
        mSwipeLayout.setDistanceToTriggerSync(200);// 设置手指在屏幕下拉多少距离会触发下拉刷新
//        mSwipeLayout.setSize(SwipeRefreshLayout.LARGE); // 设置圆圈的大小

    }

    /**
     *
     */
    class SwipeLayoutRefreshListener implements com.acheng.achengutils.widgets.swiperefreshlayout.SwipyRefreshLayout.OnRefreshListener {

        @Override
        public void onRefresh(int index) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    // 停止刷新
                    mSwipeLayout.setRefreshing(false);
                }
            }, 1500); // 5秒后发送消息，停止刷新
        }

        @Override
        public void onLoad(int index) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    // 停止刷新
                    mSwipeLayout.setRefreshing(false);
                }
            }, 1500); // 5秒后发送消息，停止刷新
        }

    }
}
